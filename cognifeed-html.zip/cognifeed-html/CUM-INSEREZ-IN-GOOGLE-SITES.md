# Cum pun paginile echipelor în Google Sites

Fiecare fișier `echipa-1.html` … `echipa-8.html` este pagina completă a unei echipe: 7 secțiuni de câte 30 de minute (Lecțiile 1–5, Atelier de creație, Recapitulare) și quizul final cu notă automată. `index.html` este pagina de start cu cele 8 echipe.

## Varianta recomandată: prin GitHub Pages (unde sunt deja fișele)
1. Deschideți depozitul `fise-etwinning-cognifeed` pe GitHub → **Add file → Upload files**.
2. Încărcați cele 9 fișiere HTML (eventual într-un folder `echipe/`) → **Commit changes**.
3. După 1–2 minute, pagina Echipei 1 are adresa:
   `https://aureliainformatician.github.io/fise-etwinning-cognifeed/echipa-1.html`
4. În Google Sites, pe pagina echipei: **Inserare → Încorporare → După adresa URL** → lipiți adresa → **Inserare**. Trageți de colț ca fereastra să fie cât toată pagina.
5. Repetați pentru celelalte 7 echipe (câte o pagină Google Sites pe echipă).

## Varianta rapidă: cod încorporat
1. Deschideți `echipa-N.html` cu Notepad, selectați tot (Ctrl+A) și copiați (Ctrl+C).
2. În Google Sites: **Inserare → Încorporare → Încorporați codul** → lipiți → **Următorul → Inserare**.
3. Dacă Google Sites refuză codul (prea lung) sau butonul „Descarcă” nu merge în fereastra încorporată, folosiți varianta cu GitHub.

## Cum lucrează elevii
- Răspunsurile se salvează automat în browserul calculatorului pe care lucrează echipa.
- Dacă se schimbă calculatorul: **⬇ Descarcă** pe primul calculator, apoi **⬆ Încarcă** fișierul pe al doilea.
- La final: **⬇ Descarcă** (fișier HTML cu toate răspunsurile) sau **🖨 PDF**, apoi trimiteți fișierul profesorului (Classroom, Drive, TwinSpace).
- **⤢ Filă nouă** apare doar în fereastra încorporată și deschide pagina pe tot ecranul, unde descărcarea funcționează sigur.
- Butonul **▶ Pornește 30 min** din fiecare secțiune pornește cronometrul din bara de sus.
